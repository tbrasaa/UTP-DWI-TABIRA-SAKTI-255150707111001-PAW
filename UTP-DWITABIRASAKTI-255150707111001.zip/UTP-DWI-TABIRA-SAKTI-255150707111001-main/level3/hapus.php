<?php
session_start();

unset($_SESSION["ukuran"]);
unset($_SESSION["warna"]);
unset($_SESSION["halaman"]);
unset($_SESSION["rangkap"]);
unset($_SESSION["total"]);

header("Location: ../ringkasan.php");
exit();
?>